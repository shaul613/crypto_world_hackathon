
async function func(){
  const res = await fetch(`home/1`);
  const data = await res.json();
  // console.log(data[0]);
  return data[0];
}

function insertBalance(currency){
  func().then(data => {
    const parent = document.getElementById(`${currency}b`);
    let balance = data[`${currency}_balance`];
    const text = document.createTextNode(`${currency.toUpperCase()} balance: ${balance}`);
    parent.appendChild(text);
  });
}

for(let symbol of ['btc', 'eth', 'usd']){
  insertBalance(symbol);
}



function getUsd(){ //Whatever currency you want to conver to usd
  const btcToUsd = 20000; //results from API
  const ethToUsd = 14 * btcToUsd; //results from API for currency * results from API for btc usd
  return ethToUsd;
}
